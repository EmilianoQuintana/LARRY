/**
 * Java framework for the vlc media player.
 */
package uk.co.caprica.vlcj;
