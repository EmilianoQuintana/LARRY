/**
 * Specification and base implementation for media that is provided by native media callback
 * functions.
 * <p>
 * <em>Callback media requires LibVLC 3.0.0 or later.</em>
 */
package uk.co.caprica.vlcj.player.media.callback;
