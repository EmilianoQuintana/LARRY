/**
 * Provides components that can be used to automatically discover the location
 * of the libvlc native libraries on Windows.
 */
package uk.co.caprica.vlcj.discovery.windows;
