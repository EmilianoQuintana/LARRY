/**
 * Encapsulation of various types of media.
 */
package uk.co.caprica.vlcj.player.media;
