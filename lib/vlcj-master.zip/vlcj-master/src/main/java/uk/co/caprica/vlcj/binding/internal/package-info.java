/**
 * Internal JNA bindings for libvlc, bindings to native types and structures.
 */
package uk.co.caprica.vlcj.binding.internal;
