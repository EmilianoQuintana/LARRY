/**
 * Provides the classes necessary to support direct access to the native audio
 * samples buffer.
 */
package uk.co.caprica.vlcj.player.directaudio;
