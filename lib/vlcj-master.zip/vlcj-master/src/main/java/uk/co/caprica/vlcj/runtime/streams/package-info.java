/**
 * Provides a components to interact with the native process standard output and error streams.
 */
package uk.co.caprica.vlcj.runtime.streams;
